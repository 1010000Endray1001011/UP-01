package com.kitisgang.aisgasstation.dbClass;

public class Storage {
}
