package com.kitisgang.aisgasstation.dbClass;

public class Client {
}
