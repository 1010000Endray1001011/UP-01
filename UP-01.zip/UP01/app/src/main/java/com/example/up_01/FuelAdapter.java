package com.example.up_01;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class FuelAdapter extends BaseAdapter {
    private Context context;
    private List<Fuel> fuels;

    public FuelAdapter(Context context, List<Fuel> fuels) {
        this.context = context;
        this.fuels = fuels;
    }

    @Override
    public int getCount() {
        return fuels.size();
    }

    @Override
    public Object getItem(int position) {
        return fuels.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.fuel_item, parent, false);
        }

        TextView fuelIdTV = convertView.findViewById(R.id.fuelIdTV);
        TextView fuelTypeTV = convertView.findViewById(R.id.fuelTypeTV);
        TextView octaneNumberTV = convertView.findViewById(R.id.octaneNumberTV);
        TextView stockAmountTV = convertView.findViewById(R.id.stockAmountTV);

        Fuel fuel = fuels.get(position);

        fuelIdTV.setText("ID: " + fuel.getId());
        fuelTypeTV.setText(fuel.getFuelType());

        // Цветовое оформление типов топлива
        switch (fuel.getFuelType()) {
            case "АИ-92":
                fuelTypeTV.setBackgroundColor(Color.YELLOW);
                break;
            case "АИ-95":
                fuelTypeTV.setBackgroundColor(Color.GREEN);
                break;
            case "АИ-98":
                fuelTypeTV.setBackgroundColor(Color.BLUE);
                break;
            case "АИ-100":
                fuelTypeTV.setBackgroundColor(Color.RED);
                break;
            case "ДТ":
                fuelTypeTV.setBackgroundColor(Color.GRAY);
                break;
        }

        octaneNumberTV.setText("Число: " + fuel.getOctaneNumber());
        stockAmountTV.setText("На складе: " + fuel.getStockAmount() + " л");

        return convertView;
    }
}