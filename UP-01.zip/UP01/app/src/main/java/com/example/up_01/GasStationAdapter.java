package com.example.up_01;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class GasStationAdapter extends BaseAdapter {
    private Context context;
    private List<GasStation> stations;

    public GasStationAdapter(Context context, List<GasStation> stations) {
        this.context = context;
        this.stations = stations;
    }

    @Override
    public int getCount() {
        return stations.size();
    }

    @Override
    public Object getItem(int position) {
        return stations.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.gas_station_item, parent, false);
        }

        TextView stationNumberTV = convertView.findViewById(R.id.stationNumberTV);
        TextView fuelTypeTV = convertView.findViewById(R.id.fuelTypeTV);
        TextView fuelAmountTV = convertView.findViewById(R.id.fuelAmountTV);
        TextView stationStatusTV = convertView.findViewById(R.id.stationStatusTV);

        GasStation station = stations.get(position);

        stationNumberTV.setText("№ " + station.getStationNumber());
        fuelTypeTV.setText(station.getFuelType());

        switch (station.getFuelType()) {
            case "АИ-92":
                fuelTypeTV.setBackgroundColor(Color.YELLOW);
                break;
            case "АИ-95":
                fuelTypeTV.setBackgroundColor(Color.GREEN);
                break;
            case "АИ-98":
                fuelTypeTV.setBackgroundColor(Color.BLUE);
                break;
            case "АИ-100":
                fuelTypeTV.setBackgroundColor(Color.RED);
                break;
            case "ДТ":
                fuelTypeTV.setBackgroundColor(Color.GRAY);
                break;
        }

        fuelAmountTV.setText(station.getFuelAmount() + " л");
        if (station.isWorking()) {
            stationStatusTV.setText("Исправна");
            stationStatusTV.setTextColor(Color.GREEN);
        } else {
            stationStatusTV.setText("Неисправна");
            stationStatusTV.setTextColor(Color.RED);
        }

        return convertView;
    }
}
