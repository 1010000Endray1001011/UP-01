package com.example.up_01;
public class Fuel {
    private int id;
    private String fuelType;
    private int octaneNumber;
    private double stockAmount;

    public Fuel(int id, String fuelType, int octaneNumber, double stockAmount) {
        this.id = id;
        this.fuelType = fuelType;
        this.octaneNumber = octaneNumber;
        this.stockAmount = stockAmount;
    }

    public int getId() {return id;}
    public void setId(int id) {this.id = id;}

    public String getFuelType() {return fuelType;}
    public void setFuelType(String fuelType) {this.fuelType = fuelType;}

    public int getOctaneNumber() {return octaneNumber;}
    public void setOctaneNumber(int octaneNumber) {this.octaneNumber = octaneNumber;}

    public double getStockAmount() {return stockAmount;}
    public void setStockAmount(double stockAmount) {this.stockAmount = stockAmount;}
}
