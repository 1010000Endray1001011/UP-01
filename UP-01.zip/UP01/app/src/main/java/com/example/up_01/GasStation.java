package com.example.up_01;

public class GasStation {
    private int stationNumber;
    private String fuelType;
    private double fuelAmount;
    private boolean isWorking;

    public GasStation(int stationNumber, String fuelType, double fuelAmount, boolean isWorking) {
        this.stationNumber = stationNumber;
        this.fuelType = fuelType;
        this.fuelAmount = fuelAmount;
        this.isWorking = isWorking;
    }

    public double getFuelAmount() {return fuelAmount;}
    public void setFuelAmount(double fuelAmount) {this.fuelAmount = fuelAmount;}
    public String getFuelType() {return fuelType;}
    public void setFuelType(String fuelType) {this.fuelType = fuelType;}
    public boolean isWorking() {return isWorking;}
    public void setWorking(boolean working) {isWorking = working;}
    public int getStationNumber() {return stationNumber;}
    public void setStationNumber(int stationNumber) {this.stationNumber = stationNumber;}
}
