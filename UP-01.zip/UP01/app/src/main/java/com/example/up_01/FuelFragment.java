package com.example.up_01;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class FuelFragment extends Fragment {
    private ListView listView;
    private FuelAdapter adapter;
    private List<Fuel> fuels;
    private Spinner fuelTypeSpinner;
    private EditText fuelIdInput,octaneNumberInput,stockAmountInput;
    private Button addFuelButton,deleteFuelButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fuel, container, false);

        fuelIdInput = view.findViewById(R.id.fuelIdInput);
        octaneNumberInput = view.findViewById(R.id.octaneNumberInput);
        stockAmountInput = view.findViewById(R.id.stockAmountInput);

        // Инициализация ListView
        listView = view.findViewById(R.id.fuelListView);
        fuels = new ArrayList<>();
        adapter = new FuelAdapter(requireContext(), fuels);
        listView.setAdapter(adapter);

        // Инициализация Spinner для типов топлива
        fuelTypeSpinner = view.findViewById(R.id.fuelTypeSpinner);
        String[] fuelTypes = {"АИ-92", "АИ-95", "АИ-98", "АИ-100", "ДТ"};
        ArrayAdapter<String> fuelTypeAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                fuelTypes
        );
        fuelTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fuelTypeSpinner.setAdapter(fuelTypeAdapter);

        addFuelButton = view.findViewById(R.id.addFuelButton);

        addFuelButton.setOnClickListener(v -> {
            String fuelIdStr = fuelIdInput.getText().toString();
            String octaneNumberStr = octaneNumberInput.getText().toString();
            String stockAmountStr = stockAmountInput.getText().toString();
            String fuelType = fuelTypeSpinner.getSelectedItem().toString();

            if (!fuelIdStr.isEmpty() && !octaneNumberStr.isEmpty() && !stockAmountStr.isEmpty()) {
                try {
                    int fuelId = Integer.parseInt(fuelIdStr);
                    int octaneNumber = Integer.parseInt(octaneNumberStr);
                    double stockAmount = Double.parseDouble(stockAmountStr);

                    Fuel newFuel = new Fuel(fuelId, fuelType, octaneNumber, stockAmount);

                    fuels.add(newFuel);
                    adapter.notifyDataSetChanged();

                    // Очистка полей
                    fuelIdInput.setText("");
                    octaneNumberInput.setText("");
                    stockAmountInput.setText("");
                } catch (NumberFormatException e) {
                    Toast.makeText(requireContext(), "Введите корректные числовые значения", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(requireContext(), "Заполните все поля", Toast.LENGTH_SHORT).show();
            }
        });
        deleteFuelButton = view.findViewById(R.id.deleteFuelButton);

        deleteFuelButton.setOnClickListener(v -> {
            if (!fuels.isEmpty()) {
                fuels.remove(fuels.size() - 1);
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(requireContext(), "Список пуст", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}