package com.example.up_01;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class GasStationsFragment extends Fragment {
    private ListView listView;
    private GasStationAdapter adapter;
    private List<GasStation> stations;
    private Spinner fuelTypeSpinner, stationStatusSpinner;
    private EditText stationNumberInput, fuelAmountInput;
    private Button addStationButton, deleteStationButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_gas_stations, container, false);

        // Инициализация элементов (как в предыдущем примере)
        listView = view.findViewById(R.id.gasStationListView);
        stationNumberInput = view.findViewById(R.id.stationNumberInput);
        fuelAmountInput = view.findViewById(R.id.fuelAmountInput);
        fuelTypeSpinner = view.findViewById(R.id.fuelTypeSpinner);
        stationStatusSpinner = view.findViewById(R.id.stationStatusSpinner);
        addStationButton = view.findViewById(R.id.addStationButton);
        deleteStationButton = view.findViewById(R.id.deleteStationButton);

        // Инициализация списка и адаптера
        stations = new ArrayList<>();
        adapter = new GasStationAdapter(requireContext(), stations);
        listView.setAdapter(adapter);

        // Настройка спиннеров (как в предыдущем примере)
        String[] fuelTypes = {"АИ-92", "АИ-95", "АИ-98", "АИ-100", "ДТ"};
        ArrayAdapter<String> fuelTypeAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                fuelTypes
        );
        fuelTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fuelTypeSpinner.setAdapter(fuelTypeAdapter);

        String[] statusTypes = {"Исправна", "Неисправна"};
        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                statusTypes
        );
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stationStatusSpinner.setAdapter(statusAdapter);

        // Обработчик кнопки добавления
        addStationButton.setOnClickListener(v -> {
            // Получаем значения из полей ввода и спиннеров
            String stationNumberStr = stationNumberInput.getText().toString();
            String fuelAmountStr = fuelAmountInput.getText().toString();
            String fuelType = fuelTypeSpinner.getSelectedItem().toString();
            String stationStatus = stationStatusSpinner.getSelectedItem().toString();

            // Проверяем, что все поля заполнены
            if (!stationNumberStr.isEmpty() && !fuelAmountStr.isEmpty()) {
                try {
                    int stationNumber = Integer.parseInt(stationNumberStr);
                    double fuelAmount = Double.parseDouble(fuelAmountStr);
                    boolean isWorking = stationStatus.equals("Исправна");

                    // Создаем новую бензоколонку
                    GasStation newStation = new GasStation(
                            stationNumber,
                            fuelType,
                            fuelAmount,
                            isWorking
                    );

                    // Добавляем в список и обновляем адаптер
                    stations.add(newStation);
                    adapter.notifyDataSetChanged();

                    // Очищаем поля ввода
                    stationNumberInput.setText("");
                    fuelAmountInput.setText("");
                } catch (NumberFormatException e) {
                    Toast.makeText(requireContext(), "Введите корректные числовые значения", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(requireContext(), "Заполните все поля", Toast.LENGTH_SHORT).show();
            }
        });

        // Обработчик кнопки удаления
        deleteStationButton.setOnClickListener(v -> {
            if (!stations.isEmpty()) {
                // Удаляем последний элемент
                stations.remove(stations.size() - 1);
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(requireContext(), "Список пуст", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
